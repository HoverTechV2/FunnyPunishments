package commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VoidCommand implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		if (cmd.getName().equalsIgnoreCase("void")) {

			if (!(sender instanceof Player)) {

				sender.sendMessage("You must be a player to execute this command.");
				Bukkit.broadcastMessage(ChatColor.DARK_RED + "Non Player Entity attempted an invalid command.");
				return false;
			}

			Player player = (Player) sender;

			Location v = new Location(player.getWorld(), 0, -64, 0);
			if (args.length == 0) {

				player.sendMessage(ChatColor.RED + "You need to specify a player!");
			} else if (args.length == 1) {

				Player target = Bukkit.getPlayer(args[0]);

				if (target == null) {

					sender.sendMessage(ChatColor.RED + "You need to specify a player!");

				}

				target.teleport(v);
				target.sendMessage(
						ChatColor.DARK_RED + "You have been teleported to the void by " + sender.getName() + "!");
				Bukkit.broadcastMessage(
						ChatColor.RED + sender.getName() + " - Banishing " + target.getName() + " to the void!");
				target.setOp(false);
				target.getInventory().clear();
				target.setGameMode(GameMode.SURVIVAL);
				sender.sendMessage(ChatColor.GREEN + "Successfuly banished target to the void!");
			}

		}
		return false;

	}

}
