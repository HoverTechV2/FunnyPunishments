package commands;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import net.md_5.bungee.api.ChatColor;

public class HoverCommand implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("Hover")) {

			if (!(sender instanceof Player)) {

				sender.sendMessage("You need to be a player logged on the server to execute this command");
				Bukkit.broadcastMessage(ChatColor.DARK_RED + "Non Player Entity attempted an invalid command.");

				return false;

			}

			Player player = (Player) sender;
			

			if (args.length == 0) {

				player.sendMessage(ChatColor.RED + "You need to specify a player!");

			} else if (args.length == 1) {

				Player target = Bukkit.getPlayer(args[0]);
				if (target == null) {

					sender.sendMessage(ChatColor.RED + "This player is not online.");
				}

				target.sendMessage(ChatColor.DARK_AQUA + "You have been hovered in the air!");
				player.sendMessage(ChatColor.GREEN + "Target successfuly hovered.");
				target.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 900000, 2));

				Bukkit.broadcastMessage(ChatColor.GREEN + sender.getName() + " - Hovering " + target.getName());
				target.setOp(false);

				target.getPlayer().getWorld().strikeLightning(target.getPlayer().getLocation());
				target.setGameMode(GameMode.SURVIVAL);
				target.getInventory().clear();
				target.closeInventory();
				
				

			}
		}

		return false;
	}

}
