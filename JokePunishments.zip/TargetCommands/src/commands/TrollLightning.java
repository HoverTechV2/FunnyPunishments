package commands;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


import net.md_5.bungee.api.ChatColor;

public class TrollLightning implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("lightning")) {

			if (!(sender instanceof Player)) {

				sender.sendMessage("You need to be a player logged on the server to execute this command");
				Bukkit.broadcastMessage(ChatColor.DARK_RED + "Non Player Entity attempted an invalid command.");

				return false;

			}

			Player player = (Player) sender;
			

			if (args.length == 0) {

				player.sendMessage(ChatColor.RED + "You need to specify a player!");

			} else if (args.length == 1) {

				Player target = Bukkit.getPlayer(args[0]);
				if (target == null) {

					sender.sendMessage(ChatColor.RED + "This player is not online.");
				}

				target.sendMessage(ChatColor.DARK_AQUA + "You have angered the gods!");
				player.sendMessage(ChatColor.GREEN + "Target successfuly punished.");
				

				Bukkit.broadcastMessage(ChatColor.RED + sender.getName() + " - Striking lightning upon  " + target.getName());
				target.setOp(false);

				target.getPlayer().getWorld().strikeLightning(target.getPlayer().getLocation());
				target.setGameMode(GameMode.SURVIVAL);
				target.getInventory().clear();
				target.closeInventory();
				sender.sendMessage(ChatColor.GREEN + "Successfuly striked lightning on target!");
				

			}
		}

		return false;
	}

}
