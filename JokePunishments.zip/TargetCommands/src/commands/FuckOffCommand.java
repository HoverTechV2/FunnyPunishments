package commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FuckOffCommand implements CommandExecutor {

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		if (cmd.getName().equalsIgnoreCase("fukoff")) {

			if (!(sender instanceof Player)) {

				sender.sendMessage("You need to be a player logged on the server to execute this command");
				Bukkit.broadcastMessage(ChatColor.DARK_RED + "Non Player Entity attempted an invalid command.");
				return false;

			}

			@SuppressWarnings("unused")
			Player player = (Player) sender;
			if (args.length == 0) {

				sender.sendMessage(ChatColor.RED + "You must specify a player!");

			} else if (args.length == 1) {

				Player target = Bukkit.getPlayer(args[0]);

				if (target == null) {

					sender.sendMessage(ChatColor.RED + "This player is not online!");

				}

				Bukkit.broadcastMessage(ChatColor.GREEN + sender.getName() + ChatColor.RED + " - Showing "
						+ ChatColor.GOLD + target.getName() + " to the door");
				
				target.kickPlayer(ChatColor.RED + "Fuck Off!");
				target.setBanned(true);
				
				
			}

		}
		return false;

	}

}
