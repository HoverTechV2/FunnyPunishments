package com.devhover.targetcommands;

import java.util.logging.Logger;

import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

import commands.FuckOffCommand;
import commands.HellCommand;
import commands.HoverCommand;
import commands.TrollLightning;
import commands.VoidCommand;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
public class Main extends JavaPlugin implements Listener {
	
	public void onEnable() {
		
		PluginDescriptionFile pdfile = getDescription();
		Logger logger = Logger.getLogger("Minecraft");
		logger.info(pdfile.getName() + " has been enabled. Running version " + pdfile.getVersion() + " by HoverTechV2.");
		//-NOTE- Remeber to fix the spacing between 'version' and 'by'.
		registerCommands();
		logger.info(pdfile.getName() + " usages have been registered.");
		getConfig().options().copyDefaults(true);
		saveConfig();
	}
	

	public void onDisable() {
		
		PluginDescriptionFile pdfile = getDescription();
		Logger logger = Logger.getLogger("Minecraft");
		logger.info(pdfile.getName() + " has been Disabled. Running version " + pdfile.getVersion() + " by HoverTechV2.");
		
		
	}
	
	public void registerCommands() {
		
		getCommand("hover").setExecutor(new HoverCommand());
		getCommand("void").setExecutor(new VoidCommand());
		getCommand("hell").setExecutor(new HellCommand());
		getCommand("lightning").setExecutor(new TrollLightning());
		getCommand("fukoff").setExecutor(new FuckOffCommand());
	}
	
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e) {
		
		
		
		ChatColor.translateAlternateColorCodes('&', getConfig().getString("message"));
		e.getPlayer().sendMessage(getConfig().getString("message"));
		
	}
	
	
	
}
